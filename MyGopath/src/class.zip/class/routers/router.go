package routers

import (
	"class/controllers"

	"github.com/astaxie/beego"
)

func init() {
	beego.Router("/", &controllers.MainController{})
	beego.Router("/abc", &controllers.MainController{})
	beego.Router("/register", &controllers.MainController{})
	beego.Router("/test",&controllers.MainController{},"get:Test")
	//注意：当实现了自定义的get请求方法，请求将不会访问默认方法
	beego.Router("/login", &controllers.MainController{}, "get:ShowLogin;post:HandleLogin")
	beego.Router("/index", &controllers.MainController{}, "get:ShowIndex;post:HandleSelect")
	//添加功能
	beego.Router("/addArticle", &controllers.MainController{}, "get:ShowAdd;post:HandleAdd")
	//查询功能
	beego.Router("/content", &controllers.MainController{}, "get:ShowContent")
	//更新文章功能
	beego.Router("/update", &controllers.MainController{}, "get:ShowUpdate;post:HandleUpdate")
	//删除文章功能
	beego.Router("/delete", &controllers.MainController{}, "get:Delete")
	//分类类型
	beego.Router("/addType", &controllers.MainController{}, "get:ShowAddType;post:HandleAddType")
	//删除类型
	beego.Router("/deleteType", &controllers.MainController{}, "get:DeleteType")

}
