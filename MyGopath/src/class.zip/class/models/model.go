package models

import (
	"time"

	"github.com/astaxie/beego/orm"
	_ "github.com/go-sql-driver/mysql"
)

//表的设计

type User struct {
	Id       int
	Name     string `orm:"unique"`
	Pwd      string
	Articles []*Aticle `orm:"rel(m2m)"`
}
//文章表和文章类型表是一对多
type Aticle struct {
	Id2       int       `orm:"pk;auto"`
	Aname    string    `orm:"size(20)"`//文件标题
	Atime    time.Time `orm:"type(datatime);auto_now_add"`//发布时间
	Acount   int       `orm:"default(0);null"`//阅读量
	Acontent string`orm:"size(500)"`//内容
	Aimg     string `orm:"size(50);null"`//图片
	AType    *AticleType `orm:"rel(fk)"` //设置的外键
	AUsers   []*User     `orm:"reverse(many)"` //关系表
}

type AticleType struct {
	Id       int
	TypeName string    `orm:"size(20)"`
	Articles []*Aticle `orm:"reverse(many)"`
}

func init() {
	//设置数据库基本信息
	orm.RegisterDataBase("default", "mysql", "root:123456@tcp(127.0.0.1:3306)/test1?charset=utf8&loc=Asia%2FShanghai")
	orm.DefaultTimeLoc, _ = time.LoadLocation("Asia/Shanghai")
	//映射model数据
	orm.RegisterModel(new(User), new(Aticle), new(AticleType))
	//生成表
	orm.RunSyncdb("default", false, true)

}
